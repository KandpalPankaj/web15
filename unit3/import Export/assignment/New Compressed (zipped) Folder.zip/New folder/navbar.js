function navbar (){
    return`<div id="logo"><a href="index.html">PomaTo</a></div>
    <div id="input"><i class="fas fa-search"></i><input type="text" placeholder="Search for a dish" id="search"></div>
    <div><a href="random.html">Recipe of the day</a></div>
    <div ><a href="latest.html">Try latest</div>`
}

export default navbar